# Zenodo metadata for No.53 v1.0 — publication operator guide

Publication type: **Preprint** (not peer-reviewed)
Title: **Rank-Unimodality Below Alternating Two-Valued Compositions: A Computer-Assisted Proof for the Infinite Family (a,b)^m**
Creator: **Yonezu, Ryutaro** — **Independent Researcher**
Publication date: **actual public deposition date** (the manuscript itself is dated 2026-11-04; do not backdate a later public release)
Version: **1.0**
License for files: **All rights reserved / copyright reserved**. Zenodo defaults to CC-BY: **replace it with a custom license titled "All rights reserved"**; do not silently accept an open reuse license. Zenodo metadata has its own CC0 terms, independent of the files.
Keywords: generalized subword order; compositions; principal ideals; rank-unimodality; log-concavity; computer-assisted proof.

## Description to paste

This restricted mathematical preprint proves rank-unimodality for principal ideals below alternating two-valued compositions (a,b)^m, for all integers a>b>=1 and m>=1. A duplicate-free rank-polynomial recurrence, a computer-assisted all-parameter certificate for the log-concavity of Q², and a self-contained middle-rank argument yield the result. The public deposit includes a paper PDF and a reproducibility ZIP with symbolic verifiers, logs, and SHA256 manifests. The mathematical argument underwent independent AI-assisted audit (MODEL, PROOF, COMPUTATION: PASS in the supplied Claude v0.4 report), but has not been human peer-reviewed. Novelty remains INCONCLUSIVE: the full text of the 2026 Chen and Zhang preprints was not available for comparison. No claim is made to prove the conjecture for arbitrary compositions or to establish priority over uninspected work. All rights reserved.

## Files

Upload both `No53_v1.0_PREPRINT_20261104.pdf` and `No53_v1.0_REPRODUCIBILITY_20261104.zip`; verify the uploaded bytes or SHA256 if offered. Register DOI only upon actual publication. Link the final DOI to the exact public GitHub repository and Release v1.0 after both exist.
