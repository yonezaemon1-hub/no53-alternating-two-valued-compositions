#!/usr/bin/env python3
"""No.53 v0.4 tamper-evident file checker. Standard library only."""
from pathlib import Path
import hashlib
import sys
base=Path(__file__).resolve().parent
manifest=base/'SHA256SUMS.txt'
try:
    lines=manifest.read_text(encoding='utf-8').splitlines()
    assert lines and all(len(x)>66 for x in lines)
    targets=[]
    for line in lines:
        digest, filename=line.split('  ',1)
        assert len(digest)==64 and all(c in '0123456789abcdef' for c in digest)
        assert filename and filename == Path(filename).name, 'No directory traversal allowed'
        assert filename != 'SHA256SUMS.txt', 'Manifest must not list itself'
        actual=hashlib.sha256((base/filename).read_bytes()).hexdigest()
        assert actual==digest, ('SHA256 mismatch',filename)
        targets.append(filename)
    assert len(targets)==len(set(targets))
    assert set(targets)=={p.name for p in base.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'}
    print(f'PASS: exact SHA256 checked for {len(targets)} files')
except Exception as ex:
    print('FAIL-CLOSED:',repr(ex), file=sys.stderr)
    raise SystemExit(1)
