#!/usr/bin/env python3
"""Independent *finite* sanity checks for No.53; no SymPy dependencies.

Enumerates every candidate lower word directly; unlike the symbolic
certificate, it does not use the greedy recurrence to count the ideal.
It also constructs Q from elementary polynomial multiplication.
This is NOT a proof for unbounded parameters.
"""
from itertools import product


def add(x, y):
    z = [0] * max(len(x), len(y))
    for i, c in enumerate(x): z[i] += c
    for i, c in enumerate(y): z[i] += c
    return z


def mul(x, y):
    z = [0] * (len(x) + len(y) - 1)
    for i, a in enumerate(x):
        for j, b in enumerate(y): z[i+j] += a*b
    return z


def sub(x, y):
    z = add(x, [-c for c in y])
    while len(z) > 1 and z[-1] == 0: z.pop()
    return z


def Sj(j):
    return [0] + [1]*j


def Qpoly(a, b):
    return sub(mul(Sj(a), add([1], Sj(b))), Sj(b))


def recurrence(a, b, m):
    p = add([1], Sj(b))
    q = Qpoly(a, b)
    f = [1]
    for _ in range(m): f = add(p, mul(q, f))
    return f


def embedded(v, w):
    i = 0
    for limit in w:
        if i < len(v) and v[i] <= limit:
            i += 1
    return i == len(v)


def exhaustive(a, b, m):
    w = (a, b)*m
    out = [0] * (sum(w)+1)
    out[0] = 1
    for length in range(1, len(w)+1):
        for v in product(range(1, a+1), repeat=length):
            if embedded(v, w): out[sum(v)] += 1
    return out


def check():
    rank_tests = 0
    for a in range(2, 6):
        for b in range(1, a):
            for m in (1, 2, 3):
                direct, formal = exhaustive(a, b, m), recurrence(a, b, m)
                assert direct == formal, (a, b, m, direct, formal)
                rank_tests += 1
    lc_tests = 0
    for a in range(2, 41):
        for b in range(1, a):
            q = Qpoly(a, b)
            q2 = mul(q, q)
            c = q2[4:]
            assert all(t > 0 for t in c), (a, b)
            assert all(c[k]**2 >= c[k-1]*c[k+1] for k in range(1, len(c)-1)), (a, b)
            lc_tests += 1
    print('PASS direct enumeration vs recurrence:', rank_tests, 'finite cases')
    print('PASS direct Q^2 convolution log-concavity:', lc_tests, 'finite parameter pairs')
    print('LIMITATION: finite checks do not independently certify the symbolic global proof.')


if __name__ == '__main__':
    check()
