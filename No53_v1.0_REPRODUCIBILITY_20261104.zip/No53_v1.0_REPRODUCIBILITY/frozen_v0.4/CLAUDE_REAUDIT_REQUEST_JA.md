# Claudeへの再監査依頼 — No.53 v0.2（公開HOLD）

No.53 v0.1のあなたの判定を継承します。Q²補題の内部記号証明は条件付きPASS、MODEL/COMPUTATIONはPASS、PROOF-TRANSFERはPARTIAL、REFERENCESはPARTIAL、NOVELTYはINCONCLUSIVE、公開HOLDです。v0.2で主定理への移行に新しい補題を追加しました。

## 今回の新規差分

- `TRANSFER_PROOF_ADDENDUM_v0.2.md`：Chen依存を除去する m=1,2,3 の一般証明。v0.1の主張・コード・ログは無変更。
- `verify_transfer_symbolic_v0.2.py`：m=3の難しい境界の6係数式を、b>=5 の無限パラメータ領域を含めて記号的に検査。b=1,2,3,4 も個別処理。
- `independent_transfer_checks_v0.2.py`：m=1,2,3 の恒等式と係数の符号、m=3の境界式を別の整数畳み込み・二項係数法で確認。
- Windows実行スクリプトに新チェックを追加。

## 特に検証してほしい事項

1. `N=U_(a-1)U_(b+1)+x^(b-1)` と `R=1-S_b^2+S_a P^2` の恒等式が正しいか。
2. `m=2` の接続箇所で `(Q²)_(n+2)-(Q²)_(n+1)=b-1`、`R_(n+2)-R_(n+1)=-b` がすべての a>b>=1 で正しいか。三角形係数列の証明を独立導出してほしい。
3. `m=3` の例外帯 a=b+1 で、`[x^(3b+2)]Q²F1-[x^(3b+1)]Q²F1=(5b³+9b²-14b+8)/2` が任意の b>=1 で成立するか。**付属の6項分解を信用せず、まず自前で展開してほしい。**
4. 既存のPouzet–Rosenberg第一半増加定理が layered permutations の階数列に正確に適用できるか。正確な閾値 `floor(m(a+b)/2)` と引用を一次資料で確認できたか。
5. Q² の log-concavity と F_(m−2) の unimodality から、正の係数と内部ゼロの前提も含めて Keilson–Gerber を正しく使っているか。
6. `m=1,2,3` の基底、`m>=4` の帰納法は途切れないか。接続部で二番目の山ができないか。
7. Chen (2026) と Zhang (2026) の全文を取得できるなら、今回の交互二値列無限族が既知定理の直接帰結か厳しく確認すること。

判定は MODEL / PROOF-Q2 / PROOF-TRANSFER / COMPUTATION / REFERENCES / NOVELTY を分け、未検証は PARTIAL または INCONCLUSIVE としてください。元の監査PASSを v0.2 に自動継承させず、差分監査してください。公開は HOLD。
