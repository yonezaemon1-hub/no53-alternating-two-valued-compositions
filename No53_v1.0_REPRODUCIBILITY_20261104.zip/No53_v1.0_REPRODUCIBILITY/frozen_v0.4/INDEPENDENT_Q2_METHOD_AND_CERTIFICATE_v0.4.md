# No.53 v0.4 — Independent two-kernel symbolic certificate for Q²

Author: Ryutaro Yonezu — Independent Researcher  
Date: 2026-11-04 JST  
Classification: Internal computer-assisted proof, Claude re-audit requested  
Release: HOLD. Novelty: INCONCLUSIVE.

## 1. What is new since v0.3?

The independent verifier `No53_independent_q2_two_kernel_v0.4.py` **does not reuse the original verifier's five-term-numerator squaring procedure**. It works from the elementary identity

    N(x)=Q(x)/x² = U_(a-1)(x) U_(b+1)(x) + x^(b-1),
    U_r(x)=1+x+...+x^(r-1),  a>b>=1.

Let p=b+1, q=a-1, h=b-1, T=U_p U_q. The direct binomial expansion gives

    [x^k] N(x)^2 = [x^k] U_p(x)^2 U_q(x)^2
                   + 2[x^(k-h)] U_p(x)U_q(x)
                   + indicator(k=2h).

Both the first two terms come from products of truncated geometric series, with *different* denominator orders (four and two). For any integer v, let

    H_3(v) = binom(v+3,3) if v>=0, else 0;
    H_1(v) = v+1 if v>=0, else 0.

Then the coefficient is exactly

    c_k = sum_(i,j=0..2) (-1)^(i+j) binom(2,i) binom(2,j)
                H_3(k-i p-j q)
         + 2 sum_(i,j=0..1) (-1)^(i+j)
                H_1(k-h-i p-j q)
         + H_1(k-2h) -2 H_1(k-(2h+1)) + H_1(k-(2h+2)).

The last three terms are an *exact integer Kronecker impulse*, not an approximation. This formula is independently checked against direct integer convolution. The two-kernel derivation is algebraically distinct from the v0.1 certificate, although both use the same underlying N polynomial.

## 2. How the unbounded symbolic certification works

For positive integers b,d=a-b the nonzero coefficient range of N is 0..L, where L=2b+d-2. The coefficients of N² occupy 0..2L. To establish log-concavity, it suffices to check

    Delta_k = c_k²-c_(k-1)c_(k+1) >= 0

for k=1..L-1, the corresponding ranks for the reversed polynomial, and the central rank k=L. This is exact: reversing coefficients maps Delta_k to Delta_(2L-k). Because U_p U_q is palindromic, reversing N moves the spike from exponent h=b-1 to exponent q=a-1.

The parameter lattice a>b>=1 is covered by 31 infinite chambers and 105 finite corner pairs:

- Diagonal band d<=b, e=b-d>=0: d,e>=8; fixed d=1..7 with e>=8; fixed e=0..7 with d>=8; d=1..7 and e=0..7 finite corners (56).
- Far band d>b, f=d-b>=1: b,f>=8; fixed b=1..7 with f>=8; fixed f=1..7 with b>=8; b,f=1..7 finite corners (49).

The verifier automatically constructs rank intervals from the independently derived binomial hinge positions (not from the v0.1 numerator's knot list). For each interval, it proves by affine polynomial inequalities that the interval endpoints are valid, intervals are contiguous, and the active/inactive status of *every hinge* is fixed throughout the whole parameter chamber. It then constructs Delta_k as an exact symbolic polynomial on that interval and proves its nonnegativity by explicitly nonnegative monomial coefficients in independent nonnegative chamber coordinates (or, for t<=variable+constant, using a nonnegative slack variable). Intervals of fixed finite length are checked exhaustively by exact symbolic polynomial identities in the remaining unbounded parameters.

The center rank has a separate proof. All exceptional finite corners are checked using integer direct convolution (not an FFT). The `assert` statements are essential to the certificate: do not execute with `python -O`.

## 3. Results reproduced on the creation side

    PASS independent two-kernel derivation for 1012 finite row/orientation cases
    PASS exact integer corner pairs: 105
    PASS symbolic chambers: 31 intervals: 934
    CERTIFIED BY INDEPENDENT TWO-KERNEL METHOD: Q^2 LC all a>b>=1

The program terminated with exit code 0. Compare the exact log file attached. The v0.1 proof gives 892 rank intervals from a different knot construction; the counts should not be forced to agree. Both have the same mathematical lemma and cover all positive integer parameters.

## 4. Dependence, limitations, and status

- This is a **second computer-assisted symbolic certificate**, not a hand-only proof or peer review. The two checkers share the high-level parameter chamber partition and SymPy as the symbolic arithmetic library; they do not provide entirely independent mathematical foundations.
- All three components of the transfer to F_m still need to be considered together: Q² log-concavity, the first-half rank injection, and the base/inductive tail splice. The v0.2 and v0.3 notes address these, but v0.3 is still awaiting independent re-audit.
- As the SSRN full text for Chen and Zhang has not been inspected, novelty remains INCONCLUSIVE. Their public abstracts and Vatter's update are not comprehensive novelty clearance.
- No external publication is authorized.

## 5. Exact references and scope

- Vincent Vatter, *An Assortment of Problems in Permutation Patterns*, arXiv:2602.16355v3 (2026-11-01), https://arxiv.org/html/2602.16355v3
- Maurice Pouzet, *When is the orbit algebra of a group an integral domain? Proof of a conjecture of P. J. Cameron*, RAIRO 42 (2008), DOI 10.1051/ita:2007054, https://www.numdam.org/articles/10.1051/ita:2007054/
- Lizhong Chen, *Rank-unimodality and tail log-concavity of composition ideals*, publicly visible SSRN abstract 7385218 (2026-09-03, revised 2026-10-06), https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7385218
- Zhanhe Zhang, *Rank-Unimodality for One-Descent Families in Generalized Subword Order*, publicly visible SSRN abstract 7397439 (2026-09-05), https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7397439
