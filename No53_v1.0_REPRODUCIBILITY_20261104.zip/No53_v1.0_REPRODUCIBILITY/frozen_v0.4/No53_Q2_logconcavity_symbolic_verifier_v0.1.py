#!/usr/bin/env python3
"""No.53: unbounded symbolic certificate for log-concavity of Q_{a,b}(x)^2.

Claim: for all integers a>b>=1, Q=S_a(1+S_b)-S_b and Q^2 has
log-concave nonzero coefficients (S_j=x+...+x^j).

Method: set d=a-b, N=Q/x^2 and L=deg N=2*b+d-2.
(1-x)^2*N = 1 + x^(b-1) - 2*x^b - x^(b+d-1) + x^(2*b+d).
The coefficients of N^2 are cubic splines, given by the square of the
sparse numerator divided by (1-x)^4. On each parameter chamber and
rank interval, the log-concavity determinant is a polynomial. Every
polynomial is certified nonnegative by nonnegative monomial coefficients
in explicitly nonnegative coordinates. Parameter/knot order and active
terms are separately certified by affine inequalities.

This certifies only the Q^2 lemma, not novelty, and is NOT peer review.
Requires the freely available SymPy library, no network or cloud APIs.
"""
import sys
from collections import defaultdict
from functools import lru_cache
from sympy import Integer, Poly, expand, symbols

B, D, E, F, T, U, V = symbols('B D E F T U V', integer=True)


def cubic(z):
    return expand(z*(z-1)*(z-2)/6)


def head(reverse):
    if reverse:
        return [(Integer(0), 1), (B+1,-1), (B+D,-2), (B+D+1,1), (2*B+D,1)]
    return [(Integer(0), 1), (B-1,1), (B,-2), (B+D-1,-1), (2*B+D,1)]


@lru_cache(None)
def squared_terms(reverse):
    out=defaultdict(int)
    h=head(reverse)
    for e,c in h:
        for f,v in h:
            out[expand(e+f)] += c*v
    return tuple((e,c) for e,c in out.items() if c)


def at_sample(expr, sample):
    d,e=sample
    return int(expr.subs({B:d+e,D:d})) if hasattr(expr,'subs') else int(expr)


@lru_cache(None)
def pieces(reverse, sample):
    ell=2*B+D-2
    end=at_sample(ell,sample)-1
    marks={1:Integer(1), end:ell-1}
    for exponent,_ in squared_terms(reverse):
        if at_sample(exponent,sample)>end+2:
            continue
        for offset in (-1,0,1):
            x=expand(exponent+offset)
            k=at_sample(x,sample)
            if 1<=k<=end:
                marks[k]=x
    vals=sorted(marks)
    result=[]
    for i,v in enumerate(vals):
        result.append((marks[v],marks[v],v==v))
        if i+1<len(vals) and vals[i+1]>=v+2:
            result.append((marks[v]+1, marks[vals[i+1]]-1, False))
    return tuple(result)


@lru_cache(None)
def rank_det(lo, reverse, sample):
    cs=[]
    for shift in (-1,0,1):
        k=lo+T+shift
        v=at_sample(lo,sample)+shift
        cs.append(expand(sum(w*cubic(k-e+3)
            for e,w in squared_terms(reverse)
            if v>=at_sample(e,sample))))
    return expand(cs[1]**2-cs[0]*cs[2])


@lru_cache(None)
def central_det(sample):
    ell=2*B+D-2
    cs=[]
    for shift in (-1,0,1):
        k=ell+shift
        v=at_sample(k,sample)
        cs.append(expand(sum(w*cubic(k-e+3)
            for e,w in squared_terms(False)
            if v>=at_sample(e,sample))))
    return expand(cs[1]**2-cs[0]*cs[2])


def chambers():
    # The diagonal band: d<=b, set e=b-d>=0.
    yield ('diag',None,(12,15),'diagonal interior')
    for d in range(1,8):
        yield ('diag_d',d,(d,15),'fixed d')
    for e in range(8):
        yield ('diag_e',e,(15,e),'fixed e')
    # The far band: d>b, set f=d-b>=1.
    yield ('far',None,(27,-15),'far interior')
    for b in range(1,8):
        yield ('far_b',b,(b+15,-15),'fixed b')
    for f in range(1,8):
        yield ('far_f',f,(15+f,-f),'fixed f')


def transform(expr,kind,val):
    if kind=='diag':
        return expand(expr.subs(B,D+E).subs({D:8+U,E:8+V}))
    if kind=='diag_d':
        return expand(expr.subs(B,D+E).subs({D:val,E:8+U}))
    if kind=='diag_e':
        return expand(expr.subs(B,D+E).subs({D:8+U,E:val}))
    if kind=='far':
        return expand(expr.subs(D,B+F).subs({B:8+U,F:8+V}))
    if kind=='far_b':
        return expand(expr.subs(D,B+F).subs({B:val,F:8+U}))
    if kind=='far_f':
        return expand(expr.subs(D,B+F).subs({B:8+U,F:val}))
    raise AssertionError(kind)


def nonnegative_coeffs(expr,variables):
    p=Poly(expand(expr),*variables)
    assert not p.as_expr().free_symbols.difference(set(variables)), 'unbound symbol'
    return all(c>=0 for _,c in p.terms())


def affine_nonnegative(expr):
    p=Poly(expand(expr),U,V)
    assert all(sum(degrees)<=1 for degrees,_ in p.terms()), 'not affine'
    return nonnegative_coeffs(expr,(U,V))


def polynomial_for_certificate(expr,lo,hi,kind,val):
    length=expand(hi-lo)
    is_single=(lo==hi)
    if kind.startswith('diag'):
        expr=expr.subs(B,D+E)
        length=length.subs(B,D+E)
    else:
        expr=expr.subs(D,B+F)
        length=length.subs(D,B+F)
    if is_single:
        expr=expr.subs(T,0)
    if kind in ('diag','far'):
        parameters=(D,E) if kind=='diag' else (B,F)
        par1,par2=parameters
        if not is_single and length.has(par1) and not length.has(par2) and expand(length).coeff(par1)==1:
            lower=expand(par1-length)
            expr=expr.subs({par1:T+lower+U,par2:8+V})
        elif not is_single and length.has(par2) and not length.has(par1) and expand(length).coeff(par2)==1:
            lower=expand(par2-length)
            expr=expr.subs({par1:8+U,par2:T+lower+V})
        else:
            expr=expr.subs({par1:8+U,par2:8+V})
        assert nonnegative_coeffs(expr,(U,V,T)),(kind,lo,hi,'not nonnegative polynomial')
        return
    if kind in ('diag_d','diag_e'):
        fixed,variable=(D,E) if kind=='diag_d' else (E,D)
    else:
        fixed,variable=(B,F) if kind=='far_b' else (F,B)
    expr=expr.subs(fixed,val)
    length=expand(length.subs(fixed,val))
    if not is_single and length.has(variable):
        assert expand(length).coeff(variable)==1
        lower=expand(variable-length)
        expr=expr.subs(variable,T+lower+U)
        assert nonnegative_coeffs(expr,(U,T)),(kind,val,lo,hi,'variable-bound polynomial')
    elif not is_single and length.is_number:
        # This length is fixed by the frozen parameter, so check every t.
        assert int(length)>=0
        for t in range(int(length)+1):
            result=expr.subs({variable:8+U,T:t})
            assert nonnegative_coeffs(result,(U,)),(kind,val,lo,hi,'fixed t',t)
    else:
        expr=expr.subs(variable,8+U)
        assert nonnegative_coeffs(expr,(U,T)),(kind,val,lo,hi,'unbounded t')


def certify_one(kind,val,sample):
    intervals=0
    ell=2*B+D-2
    for reverse in (False,True):
        ranges=pieces(reverse,sample)
        assert transform(ranges[0][0]-1,kind,val)==0
        assert transform(ranges[-1][1]-(ell-1),kind,val)==0
        terms=squared_terms(reverse)
        for i,(lo,hi,_) in enumerate(ranges):
            intervals += 1
            assert affine_nonnegative(transform(hi-lo,kind,val)),(kind,val,reverse,i,'negative length')
            if i+1<len(ranges):
                assert transform(ranges[i+1][0]-hi-1,kind,val)==0,(kind,val,reverse,i,'gap')
            # Certify that the sample-determined numerator terms remain
            # active/inactive for EVERY parameter point and rank in this interval.
            for shift in (-1,0,1):
                for exponent,_ in terms:
                    active=(at_sample(lo,sample)+shift>=at_sample(exponent,sample))
                    difference=(lo+shift-exponent) if active else (exponent-hi-shift-1)
                    assert affine_nonnegative(transform(difference,kind,val)),\
                        (kind,val,reverse,i,'activation',shift,exponent)
            polynomial_for_certificate(rank_det(lo,reverse,sample),lo,hi,kind,val)
    # The central rank has its own set of active numerator terms.
    # Certify that these terms do not change across the entire chamber.
    for shift in (-1,0,1):
        for exponent,_ in squared_terms(False):
            active=(at_sample(ell+shift,sample)>=at_sample(exponent,sample))
            difference=(ell+shift-exponent) if active else (exponent-ell-shift-1)
            assert affine_nonnegative(transform(difference,kind,val)), \
                (kind,val,'central activation',shift,exponent)
    center=central_det(sample)
    if kind in ('diag','far'):
        assert nonnegative_coeffs(transform(center,kind,val),(U,V))
    else:
        assert nonnegative_coeffs(transform(center,kind,val),(U,))
    return intervals


def n_coefficients(a,b):
    d=a-b
    assert a>b>=1
    return list(range(1,b))+[b+1]*d+list(range(b,0,-1))


def self_convolution(seq):
    out=[0]*(2*len(seq)-1)
    for i,x in enumerate(seq):
        for j,y in enumerate(seq):
            out[i+j]+=x*y
    return out


def certify_finite():
    ncases=0
    for d in range(1,8):
        for e in range(8):
            b=d+e
            c=self_convolution(n_coefficients(b+d,b))
            assert all(c[i]**2>=c[i-1]*c[i+1] for i in range(1,len(c)-1))
            ncases+=1
    for b in range(1,8):
        for f in range(1,8):
            d=b+f
            c=self_convolution(n_coefficients(b+d,b))
            assert all(c[i]**2>=c[i-1]*c[i+1] for i in range(1,len(c)-1))
            ncases+=1
    return ncases


def main():
    count=0
    intervals=0
    for kind,val,sample,_label in chambers():
        n=certify_one(kind,val,sample)
        count+=1
        intervals+=n
        print('PASS',kind,val if val is not None else '*','intervals',n,flush=True)
    finite=certify_finite()
    print('PASS: symbolic chambers',count)
    print('PASS: symbolic rank intervals',intervals)
    print('PASS: finite exceptional parameter pairs',finite)
    print('PROVED: Q_{a,b}(x)^2 has log-concave nonzero coefficients for ALL integers a>b>=1.')
    print('LIMITATION: this does not by itself prove novelty or independently audit the rank recurrence.')


if __name__=='__main__':
    try:
        main()
    except Exception as e:
        print('FAIL-CLOSED:',repr(e),file=sys.stderr)
        raise
