#!/usr/bin/env python3
"""No.53 v0.4: independently derived symbolic Q^2 coefficient certificate.

Unlike the v0.1 verifier, this checker NEVER squares the sparse five-term
numerator of N/(1-x)^2, and never reverses a sparse numerator. It derives:

 N = U_{b+1} U_{a-1} + x^(b-1),
 [x^k]N^2 = [x^k]U_{b+1}^2 U_{a-1}^2
             +2[x^(k-b+1)]U_{b+1}U_{a-1} + 1_{k=2b-2}.

Each term uses independent binomial inclusion/exclusion; the Kronecker
impulse uses a finite difference of linear hinge functions. Exact affine
cell certificates prove all log-concavity determinants nonnegative.
No external API or network. SymPy required. Fail closed.
"""
import sys
from itertools import product
from collections import defaultdict
from functools import lru_cache
from math import comb
from sympy import symbols, Poly, expand, Rational, sympify

b,d,t,u,v=symbols('b d t u v',integer=True)


def direct_row(b0,d0):
    a=b0+d0
    # Directly convolve the two positive interval polynomials, then add a spike.
    z=[0]*(a+b0-1)
    for i in range(b0+1):
        for j in range(a-1): z[i+j]+=1
    z[b0-1]+=1
    c=[0]*(2*len(z)-1)
    for i,x in enumerate(z):
        for j,y in enumerate(z): c[i+j]+=x*y
    return c


def knots(reverse):
    # U_p U_q is palindromic. Reversing N moves its spike to degree q.
    p,q=b+1,b+d-1
    h=q if reverse else b-1
    coeff=defaultdict(lambda: [0,0]) # [cubic coefficient, linear coefficient]
    for i in range(3):
        for j in range(3):
            coeff[expand(i*p+j*q)][0]+=(-1)**(i+j)*comb(2,i)*comb(2,j)
    for i in range(2):
        for j in range(2):
            coeff[expand(h+i*p+j*q)][1]+=2*(-1)**(i+j)
    # delta_{k,2h}=H1(k-2h)-2 H1(k-(2h+1))+H1(k-(2h+2))
    for offset,c in [(0,1),(1,-2),(2,1)]:
        coeff[expand(2*h+offset)][1]+=c
    return sorted([(e,aa,cc) for e,(aa,cc) in coeff.items() if aa or cc],
                  key=lambda item:(int(item[0].subs({b:20,d:13})),str(item[0])))


def binomial3(z): return expand((z+1)*(z+2)*(z+3)/6)

def kernel1(z): return z+1


def chambers():
    # Partition is a geometric fact about the *two interval lengths* p,q.
    # Boundary width 7 follows from all knots being degree-one in (b,d).
    yield ('diag',None,(27,12))  # d=12, e=15 => b=27
    for x in range(1,8): yield ('diag_d',x,(x+15,x))
    for x in range(8): yield ('diag_e',x,(15+x,15))
    yield ('far',None,(12,27)) # b=12, d=27
    for x in range(1,8): yield ('far_b',x,(x,x+15))
    for x in range(1,8): yield ('far_f',x,(15,15+x))


def subst_chamber(expr,kind,fixed):
    if kind=='diag': return expand(expr.subs({b:16+u+v,d:8+u}, simultaneous=True))
    if kind=='diag_d': return expand(expr.subs({b:fixed+8+u,d:fixed}, simultaneous=True))
    if kind=='diag_e': return expand(expr.subs({b:8+u+fixed,d:8+u}, simultaneous=True))
    if kind=='far': return expand(expr.subs({b:8+u,d:16+u+v}, simultaneous=True))
    if kind=='far_b': return expand(expr.subs({b:fixed,d:fixed+8+u}, simultaneous=True))
    if kind=='far_f': return expand(expr.subs({b:8+u,d:8+u+fixed}, simultaneous=True))
    raise RuntimeError(kind)


def as_int(expr,bd):
    return int(sympify(expr).subs({b:bd[0],d:bd[1]}))


def has_nonnegative_coeffs(expr,vars=(u,v,t)):
    po=Poly(expand(expr),*vars)
    assert not po.as_expr().free_symbols.difference(set(vars)),('unbound',po.as_expr())
    return all(co>=0 for _,co in po.terms())


def aff_positive(expr,kind,fixed):
    e=subst_chamber(expr,kind,fixed)
    p=Poly(e,u,v)
    assert all(sum(m)<=1 for m,_ in p.terms()), ('non affine',e)
    assert has_nonnegative_coeffs(e,(u,v)), ('affine invalid',kind,fixed,e)


def polynomial_positive(poly,lo,hi,kind,fixed):
    # Establish positivity over all nonnegative independent chamber coords
    # and all integer t with 0<=t<=hi-lo. Not a finite substitution test.
    L=expand(hi-lo)
    assert not L.has(t)
    x=subst_chamber(poly,kind,fixed)
    lam=subst_chamber(L,kind,fixed)
    if lo==hi:
        assert has_nonnegative_coeffs(x.subs(t,0)),(kind,fixed,'point',lo)
        return
    if not lam.has(u,v):
        assert int(lam)>=0
        for j in range(int(lam)+1):
            assert has_nonnegative_coeffs(x.subs(t,j),(u,v)),(kind,fixed,lo,hi,'t',j)
        return
    # A strip condition t<=u+c can be made t+slack=u+c;
    # this independently incorporates the rank bound into the certificate.
    for var,other in ((u,v),(v,u)):
        if expand(lam).coeff(var)==1 and not expand(lam).has(other):
            slack=symbols('_slack',nonnegative=True, integer=True)
            repl=expand(t+slack-(lam-var))
            substituted=expand(x.subs(var,repl))
            assert has_nonnegative_coeffs(substituted,(t,slack,other)),\
                (kind,fixed,'bounded positivity',lo,hi,str(substituted)[:500])
            return
    assert has_nonnegative_coeffs(x),(kind,fixed,'strong positivity',lo,hi,lam)


def analyze_region(kind,fixed,bd):
    L=2*b+d-2
    L0=as_int(L,bd)
    assert L0>=1
    n_int=0
    for reverse in (False,True):
        terms=knots(reverse)
        candidates={1:sympify(1),L0-1:L-1}
        for e,aa,cc in terms:
            for shift in (-1,0,1):
                for delta in (0,):
                    x=expand(e-shift+delta)
                    val=as_int(x,bd)
                    if 1<=val<=L0-1:
                        if val in candidates:
                            # sample collisions must be a symbolic identity across chamber
                            aff_positive(candidates[val]-x,kind,fixed)
                            aff_positive(x-candidates[val],kind,fixed)
                        else: candidates[val]=x
        ks=sorted(candidates)
        assert 1 in ks and L0-1 in ks
        ranges=[]
        for j,k in enumerate(ks):
            ranges.append((candidates[k],candidates[k]))
            if j+1<len(ks) and ks[j+1]>k+1:
                ranges.append((candidates[k]+1,candidates[ks[j+1]]-1))
        aff_positive(ranges[0][0]-1,kind,fixed)
        aff_positive(1-ranges[0][0],kind,fixed)
        aff_positive(ranges[-1][1]-(L-1),kind,fixed)
        aff_positive(L-1-ranges[-1][1],kind,fixed)
        for j,(lo,hi) in enumerate(ranges):
            aff_positive(hi-lo,kind,fixed)
            if j+1<len(ranges):
                gap=expand(ranges[j+1][0]-hi-1)
                aff_positive(gap,kind,fixed)
                aff_positive(-gap,kind,fixed)
            rows=[]
            for shift in [-1,0,1]:
                coeff=0
                for e,aa,cc in terms:
                    active=as_int(lo+shift-e,bd)>=0
                    if active:
                        aff_positive(lo+shift-e,kind,fixed)
                        z=expand(lo+t+shift-e)
                        coeff+=aa*binomial3(z)+cc*kernel1(z)
                    else:
                        aff_positive(e-hi-shift-1,kind,fixed)
                rows.append(expand(coeff))
            det=expand(rows[1]**2-rows[0]*rows[2])
            polynomial_positive(det,lo,hi,kind,fixed)
            n_int+=1
    # central coefficient: same N non-reversed c_{L-1},c_L,c_{L+1}
    center=[]
    for shift in (-1,0,1):
        coeff=0
        for e,aa,cc in knots(False):
            active=as_int(L+shift-e,bd)>=0
            if active:
                aff_positive(L+shift-e,kind,fixed)
                coeff+=aa*binomial3(L+shift-e)+cc*kernel1(L+shift-e)
            else: aff_positive(e-L-shift-1,kind,fixed)
        center.append(expand(coeff))
    polynomial_positive(expand(center[1]**2-center[0]*center[2]),sympify(0),sympify(0),kind,fixed)
    return n_int


def corner_cases():
    count=0
    for d0 in range(1,8):
        for e0 in range(8):
            b0=d0+e0
            row=direct_row(b0,d0)
            assert all(row[i]**2>=row[i-1]*row[i+1] for i in range(1,len(row)-1))
            count+=1
    for b0 in range(1,8):
        for f0 in range(1,8):
            d0=b0+f0
            row=direct_row(b0,d0)
            assert all(row[i]**2>=row[i-1]*row[i+1] for i in range(1,len(row)-1))
            count+=1
    return count


def crosscheck():
    for b0 in range(1,23):
        for d0 in range(1,24):
            row=direct_row(b0,d0)
            L=2*b0+d0-2
            for reverse in (False,True):
                terms=knots(reverse)
                for k in range(len(row)):
                    want=row[-1-k] if reverse else row[k]
                    got=0
                    for e,aa,cc in terms:
                        off=k-as_int(e,(b0,d0))
                        if off>=0:
                            got+=aa*comb(off+3,3)+cc*(off+1)
                    assert got==want,('coefficient independent formula failed',b0,d0,reverse,k,got,want)
    return 22*23*2


def main():
    print('PASS independent two-kernel derivation for',crosscheck(),'finite row/orientation cases',flush=True)
    regions=0
    intervals=0
    for kind,fixed,bd in chambers():
        n=analyze_region(kind,fixed,bd)
        print('PASS',kind,fixed if fixed is not None else '*','rank intervals',n,flush=True)
        regions+=1
        intervals+=n
    print('PASS exact integer corner pairs:',corner_cases(),flush=True)
    print('PASS symbolic chambers:',regions,'intervals:',intervals,flush=True)
    print('CERTIFIED BY INDEPENDENT TWO-KERNEL METHOD: Q^2 LC all a>b>=1',flush=True)

if __name__=='__main__':
    try: main()
    except Exception as ex:
        print('FAIL CLOSED:',repr(ex),file=sys.stderr)
        raise
