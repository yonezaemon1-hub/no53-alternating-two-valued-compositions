# Claude独立再監査指令 — No.53 v0.4 (公開HOLD)

**目的**：No.53の主定理を、v0.1〜v0.3の既存監査結果に依存し過ぎずに再評価する。公開操作・GitHub・Zenodo登録は行わない。

対象：Ryutaro Yonezu, Independent Researcher. 主張は、a>b>=1, m>=1 で (a,b)^m の一般化部分語順序の主イデアルが階数単峰となること。

## 優先順位

1. **最優先：Q² の独立全域証明の監査**。v0.4新検証器が v0.1 と異なる導出を実装しているか確認する。`N=U_(a-1)U_(b+1)+x^(b-1)`、3項分解、二種類のbinomial hinge、Kronecker impulse、係数の反転、中心rank、31無限領域＋105境界の漏れを手で検査。**934区間のPASSだけで数学が正しいとは判断しない**。検証器に共通する論理の欠陥があり得る。
2. **必須：記号的正値証明の健全性**。rank区間の端点と連続性、項の発火条件がパラメータ全域で保存されるか、`t` の上限が正しく組み込まれるか、単項式係数の非負性が論理的に十分か、負の係数や内部ゼロを黙認しないかを確認。可能なら別のCASや別の自作コードで再証明。
3. **数学の移行**。v0.3の包含行列によるfirst-half lemmaを独立再導出し、層状順列の同型類数に対応することを確認。v0.2の基底 m=1,2,3 および R+Q²F_(m-2) の接続を一箇所ずつ証明。Ibragimov/Keilson–Gerberの適用条件と内部ゼロの扱いも監査。
4. **先行研究**。Vatter arXiv v3、Pouzet (2008)、Chen SSRN 7385218、Zhang SSRN 7397439 を識別。Chen/Zhangの全文が取れない場合はその旨を明記し、NOVELTY=INCONCLUSIVEを維持。公開要旨の主題が違うだけで「新規性PASS」にしない。
5. **差分・再現**。`SHA256SUMS.txt` を照合。v0.2由来ファイルは可能なら前回ZIPとバイト比較。Windows PowerShell 5.1の実機実行とLinuxでの再現を区別する。

## 判定形式

`MODEL / PROOF-Q2 / PROOF-MIDRANK / PROOF-BASE / PROOF-TRANSFER / COMPUTATION / REFERENCES / NOVELTY / RELEASE` をそれぞれ `PASS / PARTIAL / FAIL / INCONCLUSIVE` で判定し、**検証器のコード監査・検証器実行・独立導出を区別**すること。数式の誤りや断定過剰は実例とともに提示。**公開はHOLD固定**。
