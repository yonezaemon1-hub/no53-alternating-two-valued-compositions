#!/usr/bin/env python3
"""Unbounded symbolic proof of the six m=3 exceptional boundary coefficient identities.
Uses free SymPy; partition b=1..4 and b>=5, with symbolic activation checks.
This script does not verify the external first-half or Q² theorem.
"""
from math import comb, factorial
from sympy import Symbol, Integer, Poly, expand, factor, prod, simplify

b=Symbol('b',integer=True,positive=True)


def binpoly(t,r):
    return prod(t+j for j in range(1,r+1))/Integer(factorial(r))


def term_in_infinite_chamber(p,q,alpha,beta):
    """Prove exact coefficient of (1-x)U_b^p U_(b+1)^q at k=alpha*b+beta for all b>=5."""
    assert p+q>=2
    r=p+q-2
    total=Integer(0)
    for i in range(p+1):
        for j in range(q+1):
            slope=alpha-i-j
            intercept=beta-j
            val_at5=5*slope+intercept
            if val_at5>=0:
                assert slope>=0, ('active term would switch off',p,q,i,j)
                total+=(-1)**(i+j)*comb(p,i)*comb(q,j)*binpoly(slope*b+intercept,r)
            else:
                assert slope<=0, ('inactive term would switch on',p,q,i,j)
    return expand(total)


def pos_bin(t,r):
    return comb(t,r) if t>=r>=0 else 0


def finite_term(n,p,q,alpha,beta):
    k=alpha*n+beta
    if p+q==0:
        return int(k==0)-int(k==1)
    r=p+q-2
    return sum((-1)**(i+j)*comb(p,i)*comb(q,j)*pos_bin(k-i*n-j*(n+1)+r,r)
               for i in range(p+1) for j in range(q+1))


def main():
    # p,q,alpha,beta,multiplier
    jobs=((2,2,3,-2,1),(1,1,2,-1,2),(0,0,1,0,1),
          (2,4,3,-3,1),(1,3,2,-2,2),(0,2,1,-1,1))
    expected=(-(b*b+5*b-10)/2,-2,0,
              (5*b**3+10*b*b-25*b+12)/2,8*b-6,1)
    for index,((p,q,alpha,beta,mul),w) in enumerate(zip(jobs,expected),1):
        if p+q==0:
            got=Integer(0)
        else:
            got=mul*term_in_infinite_chamber(p,q,alpha,beta)
        assert Poly(expand(got-w),b).is_zero, ('symbolic identity',index, factor(got-w))
    print('PASS: all 6 coefficient identities as exact polynomials for every b>=5')
    for n in range(1,5):
        actual=tuple(m*finite_term(n,p,q,alpha,beta) for p,q,alpha,beta,m in jobs)
        if n==1:
            target=(1,0,-1,1,2,1)
        else:
            target=tuple(int(expand(z).subs(b,n)) if hasattr(z,'subs') else int(z) for z in expected)
        assert actual==target, ('finite exceptional',n,actual,target)
        print('PASS: b=%d, six exact binomial contributions' % n)
    closed=(5*b**3+9*b*b-14*b+8)/2
    assert Poly(expand(sum(expected)-closed),b).is_zero
    assert simplify(closed - (b*(b-1)*(5*b+14)/2+4))==0
    print('PASS: exact formula for G_(3b+2)-G_(3b+1) and positive lower bound >=4')
    print('NOTE: This symbolic checker does not reprove Pouzet--Rosenberg or Q² log-concavity.')

if __name__=='__main__':
    main()
