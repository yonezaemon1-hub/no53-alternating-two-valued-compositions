# Run from: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_windows_v0.4.ps1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Push-Location $PSScriptRoot
try {
    & python -I verify_sha256_v0.4.py
    if ($LASTEXITCODE -ne 0) { throw 'SHA256 manifest verification failed' }
    & python -I No53_independent_q2_two_kernel_v0.4.py
    if ($LASTEXITCODE -ne 0) { throw 'Independent Q2 symbolic certificate FAILED' }
    & python -I No53_Q2_logconcavity_symbolic_verifier_v0.1.py
    if ($LASTEXITCODE -ne 0) { throw 'Original Q2 symbolic certificate FAILED' }
    & python -I verify_transfer_symbolic_v0.2.py
    if ($LASTEXITCODE -ne 0) { throw 'Transfer symbolic verifier FAILED' }
    Write-Output 'PASS: No.53 v0.4 audit package script checks'
} finally {
    Pop-Location
}
