#!/usr/bin/env python3
"""Exact finite checks of proposed Chen-free No.53 base proof.
Only Python standard library. Finite checks are NOT a proof of all parameters.
"""
from math import comb


def cv(a,b):
    z=[0]*(len(a)+len(b)-1)
    for i,u in enumerate(a):
        if u:
            for j,v in enumerate(b):
                if v:z[i+j]+=u*v
    return z


def add(*xs):
    z=[0]*max(map(len,xs))
    for x in xs:
        for i,v in enumerate(x):z[i]+=v
    return z


def coeff(a,k):
    return a[k] if 0<=k<len(a) else 0


def delta(a,k):
    return coeff(a,k)-coeff(a,k-1)


def unimodal(c):
    return all(c[k+1]>=c[k] for k in range(c.index(max(c)))) and all(c[k+1]<=c[k] for k in range(c.index(max(c)), len(c)-1))


def basis(a,b):
    sa=[0]+[1]*a; sb=[0]+[1]*b; P=[1]+[1]*b
    Q=add(cv(sa,P),[-z for z in sb]); Q2=cv(Q,Q)
    F1=add(P,Q); R=cv(P,add([1],Q)); F2=add(R,Q2)
    G=cv(Q2,F1);F3=add(R,G)
    return P,Q,Q2,F1,R,F2,G,F3


def run():
    num=0
    for a in range(2,81):
        for b in range(1,a):
            n=a+b;d=a-b
            P,Q,Q2,F1,R,F2,G,F3=basis(a,b)
            T=cv([1]*(a-1),[1]*(b+1)); N=T[:]
            N[b-1]+=1
            assert Q==[0,0]+N, ('Q identity',a,b)
            assert R==add([1],cv([0]+[1]*a,cv(P,P)),[-z for z in cv([0]+[1]*b,[0]+[1]*b)]),('R identity',a,b)
            assert delta(R,n+2)==-b,('R jump',a,b)
            assert delta(Q2,n+2)==b-1,('Q² jump',a,b)
            assert delta(F2,n+2)==-1,('F2 jump',a,b)
            assert all(Q2[k+1]<=Q2[k] for k in range(n+2,len(Q2)-1)),('Q² right tail',a,b)
            assert all(R[k+1]<=R[k] for k in range(n+1,len(R)-1)),('R right tail',a,b)
            assert unimodal(F1) and unimodal(F2) and unimodal(F3),('base unimodality',a,b)
            assert all(F2[k+1]>=F2[k] for k in range(n)),('F2 first-half',a,b)
            if d>=2:
                assert (3*n)//2 >= len(R), ('m3 rank threshold',a,b)
            else:
                assert len(R)-1 == (3*n)//2
                gdiff=delta(G,3*b+2)
                expected=(5*b**3+9*b**2-14*b+8)//2
                assert gdiff==expected and gdiff>=4, ('m3 boundary polynomial',a,b)
            num+=1
    print('PASS: 3160 (a,b) parameter pairs, 2<=a<=80; Q, R, F1/F2/F3 identities and joins')

    # Verify the six explicit contributions to the exceptional m=3 boundary
    for b in range(1,201):
        A=[1]*b;B=[1]*(b+1)
        A2=cv(A,A);B2=cv(B,B);B3=cv(B2,B);B4=cv(B2,B2)
        T=cv(A,B)
        terms=(delta(cv(A2,B2),3*b-2),
               2*delta(T,2*b-1),
               delta([1],b),
               delta(cv(A2,B4),3*b-3),
               2*delta(cv(A,B3),2*b-2),
               delta(B2,b-1))
        if b==1:
            expected=(1,0,-1,1,2,1)
        else:
            expected=(-(b*b+5*b-10)//2,-2,0,
                      (5*b**3+10*b*b-25*b+12)//2,8*b-6,1)
        assert terms==expected,('six-term m3 calculation',b,terms,expected)
        assert sum(terms)==(5*b**3+9*b*b-14*b+8)//2
    print('PASS: 200 b values; all six exceptional m=3 contribution formulas')

    # Separate elementary coefficient formula using binomial expansions, no convolution.
    def bx(t,r):
        return comb(t,r) if t>=r>=0 else 0
    def term(b,p,q,k):
        if p+q==0:
            return (k==0)-(k==1)
        return sum((-1)**(i+j)*comb(p,i)*comb(q,j)*bx(k-i*b-j*(b+1)+p+q-2,p+q-2)
                   for i in range(p+1) for j in range(q+1))
    for b in range(1,201):
        vals=(term(b,2,2,3*b-2),2*term(b,1,1,2*b-1),term(b,0,0,b),
              term(b,2,4,3*b-3),2*term(b,1,3,2*b-2),term(b,0,2,b-1))
        expected=(1,0,-1,1,2,1) if b==1 else (
            -(b*b+5*b-10)//2,-2,0,(5*b**3+10*b*b-25*b+12)//2,8*b-6,1)
        assert vals==expected,('binomial extraction',b,vals,expected)
    print('PASS: 200 b values; independent binomial extraction of all six terms')
    print('NOTE: These finite checks do not substitute for symbolic auditing of the stated formulas.')


if __name__=='__main__':
    run()
