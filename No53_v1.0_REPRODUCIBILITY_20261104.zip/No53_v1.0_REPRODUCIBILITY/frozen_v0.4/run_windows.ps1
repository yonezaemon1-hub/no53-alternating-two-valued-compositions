# Windows PowerShell 5.1 — SHA256 fail-closed and Python checks.
# Run: powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_windows.ps1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
Push-Location $PSScriptRoot
try {
    $manifest = Get-Content -LiteralPath 'SHA256SUMS.txt' -Encoding UTF8
    if ($manifest.Count -eq 0) { throw 'Empty manifest' }
    $seen = @{}
    foreach ($line in $manifest) {
        if ($line -notmatch '^([0-9a-f]{64})  ([A-Za-z0-9_.-]+)$') { throw "Bad hash entry: $line" }
        $expected = $Matches[1]
        $name = $Matches[2]
        if ($seen.ContainsKey($name)) { throw "Duplicate entry: $name" }
        $seen[$name] = $true
        $actual = (Get-FileHash -LiteralPath $name -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -cne $expected) { throw "Hash mismatch: $name" }
    }
    $listed = @(Get-ChildItem -LiteralPath . -File | Where-Object { $_.Name -ne 'SHA256SUMS.txt' })
    if ($listed.Count -ne $manifest.Count) { throw 'Manifest does not list all files' }
    Write-Host "PASS SHA256: $($manifest.Count) files"
    & python -I 'independent_finite_checks.py'
    if ($LASTEXITCODE -ne 0) { throw 'Finite checks failed' }
    & python -I 'independent_transfer_checks_v0.2.py'
    if ($LASTEXITCODE -ne 0) { throw 'Transfer finite checks failed' }
    & python -I 'verify_transfer_symbolic_v0.2.py'
    if ($LASTEXITCODE -ne 0) { throw 'Transfer symbolic checks failed' }
    & python -I 'No53_Q2_logconcavity_symbolic_verifier_v0.1.py'
    if ($LASTEXITCODE -ne 0) { throw 'Symbolic verification failed' }
    Write-Host 'PASS all included checks; INDEPENDENT AUDIT STILL REQUIRED'
} catch {
    Write-Error "FAIL-CLOSED: $_"
    exit 1
} finally {
    Pop-Location
}
