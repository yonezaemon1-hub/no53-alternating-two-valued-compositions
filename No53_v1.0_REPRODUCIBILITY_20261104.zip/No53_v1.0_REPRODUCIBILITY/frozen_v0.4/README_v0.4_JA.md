# No.53 v0.4 — Claude再監査専用（非公開）

Date: 2026-11-04. Author: Ryutaro Yonezu — Independent Researcher.

STATUS: **RELEASE HOLD** / NOVELTY INCONCLUSIVE / Human peer review NOT DONE.

### 変更差分

v0.2資料（既存の証明、検証器、ログ、監査スクリプト）をバイト変更せず保持。v0.3の中央階数証明と、v0.4の別導出によるQ²無限域記号検証器＋実行ログを追加。旧README、SHA256SUMS、STATUSは履歴用に残し、**このREADMEと最上位のSHA256SUMSを現行版**とする。

### 監査の入口

1. `CLAUDE_REAUDIT_REQUEST_v0.4.md` — 今回の監査指令
2. `INDEPENDENT_Q2_METHOD_AND_CERTIFICATE_v0.4.md` — 新しい方法の数式・検証手順
3. `No53_independent_q2_two_kernel_v0.4.py` — 完全独立の係数導出による記号検証器（同じSymPy環境）
4. `No53_independent_q2_two_kernel_v0.4.log` — 実行結果
5. `No53_v0.3_MIDRANK_PRIMARY_SOURCE_AND_SELF_CONTAINED_PROOF_20261104.md` — 中央階数の自前証明
6. `TRANSFER_PROOF_ADDENDUM_v0.2.md` — m=1,2,3 と移行証明
7. `No53_Q2_logconcavity_symbolic_verifier_v0.1.py` — 元の独立系統

### 無料・オフライン再現

Python 3.10+ と **SymPy** が必要。事前導入済みならネット接続不要。未導入の場合 `python -m pip install sympy` （無償、ただしそのダウンロードはインターネットが必要）。既存の v0.1 検証器も SymPy を必要とする。

Windows PowerShell 5.1 の例：

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_windows_v0.4.ps1

Linux/macOS の例：

    python -I verify_sha256_v0.4.py
    python -I No53_independent_q2_two_kernel_v0.4.py
    python -I No53_Q2_logconcavity_symbolic_verifier_v0.1.py
    python -I verify_transfer_symbolic_v0.2.py

**注記**：こちらでの新検証器実行とZIP再検証はLinux環境。Windows実機PASSはまだ主張しない。ZIPを解凍したディレクトリから実行。検証器に`-O`を使わないこと（assertが証明の一部）。

### 凍結と公開状態

先行研究の全文照合は未了。数学の内部記号検査が通っても、新規性評価・人間査読・Claude再監査は未了。GitHub、Zenodo等への一般公開は禁止（今回の作業では実施しない）。
