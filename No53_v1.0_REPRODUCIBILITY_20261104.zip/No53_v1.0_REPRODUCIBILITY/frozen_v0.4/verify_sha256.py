#!/usr/bin/env python3
"""Fail-closed SHA256 manifest check for No.53 package (standard library only)."""
import hashlib
import pathlib
import sys

root = pathlib.Path(__file__).resolve().parent
manifest = root / 'SHA256SUMS.txt'
try:
    entries = manifest.read_text(encoding='utf-8').splitlines()
    assert entries, 'empty hash manifest'
    names = []
    for line in entries:
        digest, delim, name = line.partition('  ')
        assert delim and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest), line
        assert name and '/' not in name and '\\' not in name and name not in ('.','..'), line
        assert name not in names, 'duplicate manifest entry'
        names.append(name)
        actual = hashlib.sha256((root/name).read_bytes()).hexdigest()
        assert actual == digest, f'SHA256 mismatch: {name}'
    expected = sorted(p.name for p in root.iterdir() if p.is_file() and p.name != 'SHA256SUMS.txt')
    assert sorted(names) == expected, ('unlisted or missing files', set(expected)^set(names))
    print('PASS SHA256:', len(entries), 'files')
except Exception as exc:
    print('FAIL-CLOSED:', exc, file=sys.stderr)
    sys.exit(1)
