# No.53 v0.2 — Transfer proof addendum (Chen-independent base cases)

Author: Ryutaro Yonezu — Independent Researcher  
Date: 2026-11-04 JST  
Status: INTERNAL DERIVATION, NOT INDEPENDENTLY AUDITED. NOVELTY INCONCLUSIVE. PUBLICATION HOLD.

The original v0.1 symbolic verifier and proof note are preserved byte-for-byte; this addendum does not replace or silently upgrade the independent audit of the Q^2 lemma.

## Notation

Let integers a>b>=1, n=a+b, d=a-b, and U_j=1+x+...+x^(j-1), S_j=x U_j. Write

P=U_(b+1), Q=S_a P-S_b=x^2 N,
N=U_(a-1) U_(b+1)+x^(b-1),
T=U_(a-1) U_(b+1), L=deg T=n-2,
R=P(1+Q), F_0=1, F_m=P+Q F_(m-1).

Identity: F_1=1+S_a P=1+x U_a U_(b+1).
Identity: R=1-S_b^2+S_a P^2.
Identity: F_m=R+Q^2 F_(m-2) (m>=2).

The v0.1 Q^2 log-concavity lemma is a **hypothesis accepted only conditionally**, pending fully independent formal verification.

## First-half theorem dependency

Pouzet--Rosenberg (1986), as stated in Vatter arXiv:2602.16355v3, Section 2, ensures F_m(k+1)>=F_m(k) for 0<=k<floor(mn/2). The original paper abstract also explicitly states the rise through floor(number of points/2). Exact Corollary 2.11 text has NOT been directly inspected. The result applies to layered permutations corresponding to the compositions.

## Base m=1: direct

S_a P=x U_a U_(b+1) has log-concave, hence unimodal, nonzero coefficients by convolution of two all-ones intervals. The coefficient of x is 1, so prepending the constant coefficient 1 maintains unimodality.

## Base m=2: direct, no Chen required

Let [x^k]H=H_k. By Pouzet--Rosenberg, F_2 is nondecreasing through rank n.

For k>=n+1, R_k = [x^k] S_a P^2, because 1-S_b^2 has degree <=2b<n+1. Since S_a P^2=x U_a U_(b+1)^2 is symmetric and log-concave on degrees 1,...,a+2b, it is nonincreasing for k>=n+1. Moreover, reversal of its all-ones product shows

 R_(n+1) = binom(b+1,2), R_(n+2) = binom(b,2),
 R_(n+2)-R_(n+1)=-b.

The identity N=T+x^(b-1) decomposes its square as

 N^2=T^2+2x^(b-1) T+x^(2b-2).

Here T is symmetric, log-concave and of degree L=n-2. Consequently T^2 (center L), x^(b-1) T (center (L+2b-2)/2<=L), and the spike x^(2b-2) (at degree <=L) are each nonincreasing from degree L onwards. Therefore Q^2=x^4 N^2 is nonincreasing for degrees >=n+2.

At the one unconnected rank step, the following exact identities hold. Here is a direct finite-sum proof of the only nontrivial one. Write p=b+1, q=a-1 (so q>=p-1), and T=U_p U_q. Set A=U_p^2 and B=U_q^2. The coefficient differences B_j-B_(j-1) are +1 for 0<=j<=q-1 and -1 for q<=j<=2q-1 (and zero outside). At the central rank L=p+q-2, in the convolution (1-x)AB, the indices 0<=i<=p-2 contribute -A_i and p-1<=i<=2p-2 contribute +A_i, except that when q=p-1 the last +A_(2p-2)=+1 is absent. Since the two sums are p(p-1)/2 and p(p+1)/2 respectively, we obtain [x^L](1-x)T^2=p for q>=p, or p-1 for q=p-1. In addition T_q-T_(q-1)=-1 for q>=p, and 0 for q=p-1. The isolated spike contributes -1 exactly when q=p-1. Thus:

 if d=1: [x^L](1-x)T^2=b, [x^L](1-x)2x^(b-1)T=0,
          [x^L](1-x)x^(2b-2)=-1;
 if d>=2:[x^L](1-x)T^2=b+1, [x^L](1-x)2x^(b-1)T=-2,
          [x^L](1-x)x^(2b-2)=0.

In both cases, [x^L](1-x)N^2=b-1, hence

 (Q^2)_(n+2)-(Q^2)_(n+1)=b-1,
 (F_2)_(n+2)-(F_2)_(n+1)=-1.

Together with first-half monotonicity through n, and monotonic decrease from n+1 to n+2 and then onwards, F_2 is unimodal. (No claim that the peak must be at n+1 is needed.)

## Base m=3: direct, no Chen required

Let G=Q^2 F_1, which is unimodal by the Q^2 lemma and the standard log-concave-convolution theorem (the initial x-shift of Q^2 does not matter). Set D=deg R=a+2b=n+b.

If d>=2, floor(3n/2)>=D+1. First-half monotonicity of F_3 reaches past R's support, where F_3 agrees with G. Hence F_3 is unimodal by the tail joining argument.

If d=1, a=b+1, D=3b+1=floor(3n/2), R_D=1 and R_(D+1)=0. To bridge the single rank step, we establish

 G_(3b+2)-G_(3b+1)=(5b^3+9b^2-14b+8)/2
                        =[b(b-1)(5b+14)+8]/2 >=4.

Therefore F_3 increases from rank D to D+1 by at least 3. Since G is unimodal and strictly rising at this boundary, its subsequent values cannot create a second rise after a decline. The first-half theorem covers the earlier ranks. Hence F_3 is unimodal.

### Fully explicit coefficient calculation for the exceptional m=3 boundary

For a=b+1, T=U_b U_(b+1), N=T+x^(b-1), and F_1=1+x U_(b+1)^2. Therefore the above difference is

 [x^(3b-2)] (1-x)(T+x^(b-1))^2 (1+x U_(b+1)^2).

On expansion this is the sum of six terms:

 A=[x^(3b-2)](1-x) U_b^2 U_(b+1)^2;
 B=2[x^(2b-1)](1-x) U_b U_(b+1);
 C=[x^b](1-x);
 D= [x^(3b-3)](1-x) U_b^2 U_(b+1)^4;
 E=2[x^(2b-2)](1-x) U_b U_(b+1)^3;
 H=[x^(b-1)](1-x) U_(b+1)^2.

For b>=2, the six closed forms (in A,B,C,D,E,H order) are

 -(b^2+5b-10)/2, -2, 0,
 (5b^3+10b^2-25b+12)/2, 8b-6, 1.

For b=1, they are 1, 0, -1, 1, 2, 1 (sum 4).

These identities follow from the finite binomial coefficient extraction rule, with binom(t,r)=0 for t<r:

 [x^k](1-x) U_b^p U_(b+1)^q
 = SUM_(i=0)^p SUM_(j=0)^q (-1)^(i+j) binom(p,i)binom(q,j)
   binom(k-i*b-j*(b+1)+p+q-2,p+q-2).

When p+q=0, use [x^k](1-x)=delta(k,0)-delta(k,1) instead.
The expressions can be checked symbolically chamber by chamber (b=1 and b>=2); the standard-library independent checker also evaluates all six direct coefficients for every 1<=b<=200.

## Induction m>=4

Assume F_(m-2) unimodal. Q^2 is log-concave by the v0.1 lemma, so G_m=Q^2 F_(m-2) is unimodal by Ibragimov / Keilson--Gerber. Since deg R=n+b and for m>=4,

 floor(mn/2) >= floor(4n/2)=2n >= n+b+1=deg R+1

(the inequality uses a>b), the first-half theorem supplies nondecreasing F_m past the support of R. From there F_m=G_m. Therefore F_m is unimodal. This closes the induction using m=1,2,3 as established above.

## Scope, references and audit

The transfer proof no longer relies on the unavailable full text of Chen (2026). It still uses (i) the prior Q^2 symbolic certificate; (ii) Pouzet--Rosenberg first-half monotonicity; (iii) Ibragimov / Keilson--Gerber convolution preservation. Direct access to the original Pouzet--Rosenberg Corollary 2.11 remains an editorial and audit task. No guarantee of mathematical novelty is made; the full Chen and Zhang papers have NOT been checked for overlap.

Requested independent audit: verify the central Q^2 rank-difference identities and six binomial coefficient simplifications without relying on this note's closed forms; confirm the boundary splice, theorem applicability and novelty. This v0.2 is a proposed repair, not an externally accepted PASS.
