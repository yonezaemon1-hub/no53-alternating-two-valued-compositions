#!/usr/bin/env python3
"""Fail-closed SHA256 check for No.53 v1.0 reproduction data (Python 3.10+)."""
from pathlib import Path
import hashlib
import sys

BASE = Path(__file__).resolve().parent
MANIFEST = BASE / 'SHA256SUMS_REPRO.txt'
rows = [line.strip() for line in MANIFEST.read_text(encoding='utf-8').splitlines() if line.strip()]
assert rows, 'empty manifest'
listed = set()
for line in rows:
    h, sep, rel = line.partition('  ')
    assert sep and len(h) == 64 and all(ch in '0123456789abcdef' for ch in h), f'bad manifest: {line}'
    target = (BASE / rel).resolve()
    assert target.is_relative_to(BASE) and target.is_file(), f'missing/invalid path: {rel}'
    assert rel not in listed, f'duplicate: {rel}'
    listed.add(rel)
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    assert actual == h, f'SHA256 mismatch: {rel}'
print(f'PASS: No53 v1.0 reproduction manifest {len(rows)} files')
